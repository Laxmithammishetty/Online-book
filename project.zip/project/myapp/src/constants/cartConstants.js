export const CART_ADD_ITEM = ' CART_ADD_ITEM';
export const CART_REMOVE_ITEM = ' CART_REMOVE_ITEM';