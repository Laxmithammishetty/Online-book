export default  {
    products: [{
        _id:'1',
        name: 'The Full Stack Developer',
        category:'Full Stack Developer',
        image: '/images/a1.jfif',
        price: 60,
        author: 'Chris Northwood',
        rating: '4.5',
        numReviews: 10,
        countInStock: 10
    },
    {
        _id:'2',
        name: 'Mongo DB',
        category:'Mongo DB',
        image: '/images/a2.jpg',
        price: 80,
        author: 'Peter Membray',
        rating: 4,
        numReviews: 8,
        countInStock: 10
    },
    {
        _id:'3',
        name: 'React JS',
        category:'React JS',
        image: '/images/a3.jpg',
        price: 60,
        author: 'Claudia Alves',
        rating: 3.5,
        numReviews: 6,
        countInStock: 10
    },
    {
        _id:'4',
        name: 'Node JS',
        category:'Node JS',
        image: '/images/a4.jfif',
        price: 60,
        author: 'Azat Mardan',
        rating: 5,
        numReviews: 5,
        countInStock: 10
    },
    {
        _id:'5',
        name: 'Modern JS',
        category:'Modern JS',
        image: '/images/a5.jfif',
        price: 70,
        author: 'Federice Kareki',
        rating: 3.5,
        numReviews: 9,
        countInStock: 10
    },
    {
        _id:'6',
        name: 'HTML,CSS & JS Web Publishing',
        category:'HTML,CSS,JS',
        image: '/images/a6.jpg',
        price: 50,
        author: 'Laura Lemay',
        rating: 4.5,
        numReviews: 7,
        countInStock: 10
    },
]}